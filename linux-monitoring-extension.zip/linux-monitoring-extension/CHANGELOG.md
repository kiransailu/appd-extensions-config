# AppDynamics Extensions Linux Monitor CHANGELOG

## 2.1.6 - Oct 2, 2024
1. Updated to appd-exts-commons 2.2.13
2. Moved and updated LICENSE.txt to LICENSE
3. Added USE_CASE.md

## 2.1.5 - Jan 8, 2021
1. Updated to appd-exts-commons 2.2.4

## 2.1.4 - Jun 5, 2020
1. Disk Usgae Bug fix

## 2.1.3 - May 8, 2020
1. Moved Linux monitor to commons 2.2.3 framework

## 2.1.1 - Jan 10, 2019
1. Moved Linux monitor to commons 2.0.0 framework
2. Moved metrics configurations from config.yml to metrics.xml
3. Added filter for CPU, Disks and NFSMounts.
